var searchData=
[
  ['buscar_5findividuo',['buscar_individuo',['../class_poblacio.html#a82e917e29d78fda03e1f94cc5deb028b',1,'Poblacio']]]
];
