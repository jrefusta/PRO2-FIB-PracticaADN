var searchData=
[
  ['genere',['genere',['../class_individu.html#a65703ed67fc7ae3680f029ab299ca0c6',1,'Individu']]]
];
