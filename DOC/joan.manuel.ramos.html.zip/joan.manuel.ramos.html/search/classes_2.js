var searchData=
[
  ['par_5fcromosmas',['par_cromosmas',['../classpar__cromosmas.html',1,'par_cromosmas'],['../class_par___cromosmas.html',1,'Par_Cromosmas']]],
  ['poblacio',['Poblacio',['../class_poblacio.html',1,'Poblacio'],['../classpoblacio.html',1,'poblacio']]]
];
