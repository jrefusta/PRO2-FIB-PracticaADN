var searchData=
[
  ['te_5fmare',['te_mare',['../class_individu.html#a611aebc390831b301a7369ea6dad4e46',1,'Individu']]],
  ['te_5fpare',['te_pare',['../class_individu.html#a6972de5e5cf268c724109924d4d9e1b1',1,'Individu']]]
];
