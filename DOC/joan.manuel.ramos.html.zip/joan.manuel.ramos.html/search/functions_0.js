var searchData=
[
  ['anadir_5findividuo',['anadir_individuo',['../class_poblacio.html#a4f0ee787d73f542b695bdb7640b0c19f',1,'Poblacio']]]
];
