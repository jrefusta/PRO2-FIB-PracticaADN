var searchData=
[
  ['leer_5fcromosmas_5fn',['leer_cromosmas_n',['../class_par___cromosmas.html#a60fb703c5cbe7efb659bb416a363113c',1,'Par_Cromosmas']]],
  ['leer_5fcromosmas_5fsex',['leer_cromosmas_sex',['../class_par___cromosmas.html#a7857ea8f3ec852de93fac2f0963ceee1',1,'Par_Cromosmas']]],
  ['leer_5fcromosomas_5fn',['leer_cromosomas_n',['../class_individu.html#aa08ba93568733dcfeea8de98931e457f',1,'Individu']]],
  ['llegir_5fcomp_5fgen_5fi_5fcromosomas_5fsex',['llegir_comp_gen_i_cromosomas_sex',['../class_individu.html#aea43bd466e3296757dc38f415181617c',1,'Individu']]]
];
