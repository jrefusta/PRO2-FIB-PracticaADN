var searchData=
[
  ['reproduccio_5fcromosomes',['reproduccio_cromosomes',['../class_par___cromosmas.html#ad3a3c1e5cbcc3007862c0cb857647725',1,'Par_Cromosmas']]],
  ['reproduccion_5fsexual',['reproduccion_sexual',['../class_poblacio.html#a2967d103f843c3566fb2a7e4f97e0552',1,'Poblacio']]]
];
