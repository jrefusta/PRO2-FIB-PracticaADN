var searchData=
[
  ['par_5fcromosmas',['par_cromosmas',['../classpar__cromosmas.html',1,'par_cromosmas'],['../class_par___cromosmas.html',1,'Par_Cromosmas']]],
  ['par_5fcromosomas_2ehh',['par_cromosomas.hh',['../par__cromosomas_8hh.html',1,'']]],
  ['par_5fcromosomas_5fhh',['PAR_CROMOSOMAS_HH',['../par__cromosomas_8hh.html#a76f8c8fb616d504ef7e9ff7b6d22af93',1,'par_cromosomas.hh']]],
  ['poblacio',['Poblacio',['../class_poblacio.html',1,'Poblacio'],['../classpoblacio.html',1,'poblacio']]],
  ['poblacio_2ehh',['poblacio.hh',['../poblacio_8hh.html',1,'']]]
];
