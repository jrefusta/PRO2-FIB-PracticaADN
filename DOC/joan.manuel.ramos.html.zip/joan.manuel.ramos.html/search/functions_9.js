var searchData=
[
  ['son_5fantecesors',['son_antecesors',['../class_poblacio.html#a56baf60bde2953ed2b2069ae05b5971f',1,'Poblacio']]],
  ['son_5fgermans',['son_germans',['../class_poblacio.html#a56949cb9cd49b9e8b4a34046b232b2e6',1,'Poblacio']]]
];
