var searchData=
[
  ['individuo',['Individuo',['../class_individu.html#ab4416ff2c59e726dde0e43bc1789bcd1',1,'Individu']]]
];
