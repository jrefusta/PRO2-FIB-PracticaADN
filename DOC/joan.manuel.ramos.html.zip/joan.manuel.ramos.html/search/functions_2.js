var searchData=
[
  ['completar_5farbol_5fgenealogico',['completar_arbol_genealogico',['../class_arbol.html#a6d0fc9bf894ce3c644917298c4cd5390',1,'Arbol']]]
];
