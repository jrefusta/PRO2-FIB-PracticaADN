var searchData=
[
  ['par_5fcromosomas_2ehh',['par_cromosomas.hh',['../par__cromosomas_8hh.html',1,'']]],
  ['poblacio_2ehh',['poblacio.hh',['../poblacio_8hh.html',1,'']]]
];
