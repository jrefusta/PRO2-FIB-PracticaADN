var searchData=
[
  ['c1',['c1',['../class_par___cromosomas.html#a70838e00ad5139843ebc8babf39ba5dc',1,'Par_Cromosomas']]],
  ['c2',['c2',['../class_par___cromosomas.html#a547549b7f6e9b81750efd440b851c778',1,'Par_Cromosomas']]],
  ['completar_5farbol_5fgenealogico',['completar_arbol_genealogico',['../class_poblacion.html#a87b4f077efa7fb48f8cafef02a99e888',1,'Poblacion']]],
  ['completar_5frec',['completar_rec',['../class_poblacion.html#a36e7c84ab60787e1d491191cf079f04e',1,'Poblacion']]],
  ['composicion_5fgenetica',['composicion_genetica',['../class_individuo.html#aa1e9539df889412c32951e866f8edebc',1,'Individuo']]],
  ['crear_5fniveles',['crear_niveles',['../class_poblacion.html#a00847c8d2dd894fe1c10195f1366f636',1,'Poblacion']]],
  ['cruzar_5fnormal',['cruzar_normal',['../class_par___cromosomas.html#af140756604d9995d7e707dce9e11181f',1,'Par_Cromosomas']]],
  ['cruzar_5fsexual',['cruzar_sexual',['../class_par___cromosomas.html#a1969ec45c9893061543184d619d26732',1,'Par_Cromosomas']]]
];
