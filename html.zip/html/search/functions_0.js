var searchData=
[
  ['anadir_5fcromosomas_5fnor',['anadir_cromosomas_nor',['../class_par___cromosomas.html#a64bf911aa57f0666b9232ef500c94567',1,'Par_Cromosomas']]],
  ['anadir_5ffamilia_5fvector',['anadir_familia_vector',['../class_poblacion.html#a15dfddbb11940a26630334a85e19732f',1,'Poblacion']]],
  ['anadir_5findividuo',['anadir_individuo',['../class_poblacion.html#a585b2548324719f429d355fec10ddf23',1,'Poblacion']]],
  ['anadir_5findividuo_5fnivel',['anadir_individuo_nivel',['../class_poblacion.html#acd9ea4ec262322fe731d9f4202f7a6ae',1,'Poblacion']]],
  ['anadir_5fpadres',['anadir_padres',['../class_individuo.html#afa7e4f3a9940a7ce45223f8811b43e47',1,'Individuo']]]
];
