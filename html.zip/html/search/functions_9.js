var searchData=
[
  ['son_5fantecesores',['son_antecesores',['../class_poblacion.html#a651b8b275432713b8bdfe070b1d52276',1,'Poblacion']]],
  ['son_5fhermanos',['son_hermanos',['../class_poblacion.html#a79b691db9d2009c9e85ba539a6d368ac',1,'Poblacion']]]
];
