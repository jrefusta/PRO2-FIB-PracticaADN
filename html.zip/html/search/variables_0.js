var searchData=
[
  ['c1',['c1',['../class_par___cromosomas.html#a70838e00ad5139843ebc8babf39ba5dc',1,'Par_Cromosomas']]],
  ['c2',['c2',['../class_par___cromosomas.html#a547549b7f6e9b81750efd440b851c778',1,'Par_Cromosomas']]],
  ['composicion_5fgenetica',['composicion_genetica',['../class_individuo.html#aa1e9539df889412c32951e866f8edebc',1,'Individuo']]]
];
