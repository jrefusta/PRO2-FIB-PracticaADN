var searchData=
[
  ['leer_5fcomp_5fgen_5fy_5fcromosomas_5fsex',['leer_comp_gen_y_cromosomas_sex',['../class_individuo.html#a18d0c9a795ebd0796d69d9378c243718',1,'Individuo']]],
  ['leer_5fcromosomas_5fnor',['leer_cromosomas_nor',['../class_individuo.html#a94397f7a4d7e02cd8aacc7a49050b3fe',1,'Individuo']]],
  ['leer_5fcromosomas_5fsex',['leer_cromosomas_sex',['../class_par___cromosomas.html#a6921596a530e7e8ec76bfb374e6081ea',1,'Par_Cromosomas']]],
  ['leer_5fparcial',['leer_parcial',['../class_poblacion.html#aa9f2666c21b27be4160fb0bdb37f72df',1,'Poblacion']]]
];
