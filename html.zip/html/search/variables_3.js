var searchData=
[
  ['vector_5fcromosomas',['vector_cromosomas',['../class_individuo.html#a6d328d4738544fa9134db4e21ad5efb4',1,'Individuo']]]
];
