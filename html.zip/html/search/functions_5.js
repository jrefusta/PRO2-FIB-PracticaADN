var searchData=
[
  ['individuo',['Individuo',['../class_individuo.html#a3042a660b9789ee24dd3658248c8e0b9',1,'Individuo::Individuo()'],['../class_individuo.html#a8c6f2700f80e77c272d61456d3390d55',1,'Individuo::Individuo(int N)']]]
];
