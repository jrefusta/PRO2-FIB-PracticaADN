var searchData=
[
  ['padre',['padre',['../class_individuo.html#a0d75aa5ac6772ebd06ccc3dc06f5d0e5',1,'Individuo']]]
];
