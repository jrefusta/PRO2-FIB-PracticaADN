var searchData=
[
  ['reproduccion_5fsexual',['reproduccion_sexual',['../class_poblacion.html#ad4bc8e5d69084c4eb60a71262002f9de',1,'Poblacion']]],
  ['reproducir_5fpadres',['reproducir_padres',['../class_individuo.html#a0e04a496f40a73f35092af6e5165528a',1,'Individuo']]]
];
