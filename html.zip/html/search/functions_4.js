var searchData=
[
  ['genero',['genero',['../class_individuo.html#a59438df8becc840f730725d92e9b91ef',1,'Individuo']]]
];
