var searchData=
[
  ['completar_5farbol_5fgenealogico',['completar_arbol_genealogico',['../class_poblacion.html#a87b4f077efa7fb48f8cafef02a99e888',1,'Poblacion']]],
  ['completar_5frec',['completar_rec',['../class_poblacion.html#a36e7c84ab60787e1d491191cf079f04e',1,'Poblacion']]],
  ['crear_5fniveles',['crear_niveles',['../class_poblacion.html#a00847c8d2dd894fe1c10195f1366f636',1,'Poblacion']]],
  ['cruzar_5fnormal',['cruzar_normal',['../class_par___cromosomas.html#af140756604d9995d7e707dce9e11181f',1,'Par_Cromosomas']]],
  ['cruzar_5fsexual',['cruzar_sexual',['../class_par___cromosomas.html#a1969ec45c9893061543184d619d26732',1,'Par_Cromosomas']]]
];
