var searchData=
[
  ['buscar_5findividuo',['buscar_individuo',['../class_poblacion.html#a3bd9dcc4ea3348926b9b71b43baa5cbd',1,'Poblacion']]]
];
