var searchData=
[
  ['madre',['madre',['../class_individuo.html#adbdf1b2febf01015862cd93b58fce37c',1,'Individuo']]],
  ['mpoblacion',['mpoblacion',['../class_poblacion.html#add8cb112104b26659b52d6c69b90f062',1,'Poblacion']]]
];
