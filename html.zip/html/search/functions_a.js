var searchData=
[
  ['tiene_5fmadre',['tiene_madre',['../class_individuo.html#acd8240e136f55d251f68975f64d3468a',1,'Individuo']]],
  ['tiene_5fpadre',['tiene_padre',['../class_individuo.html#af823fa01621dd5fa91fbdd5709b59305',1,'Individuo']]]
];
