var searchData=
[
  ['par_5fcromosomas',['Par_Cromosomas',['../class_par___cromosomas.html#a704224a5124bf3e71a495e6ded095940',1,'Par_Cromosomas']]]
];
